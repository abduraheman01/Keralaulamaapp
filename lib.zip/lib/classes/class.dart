class ItemClass{
  ItemClass({
    required this.title,
    required this.imagePath,
    required this.name,
    required this.birth,
    required this.place,
    required this.teachers,
    required this.students,
    required this.services,
    required this.designation,
    required this.writings,
    required this.death,
    required this.tomb,
    required this.degree,
    
  });
  String title;
  String imagePath;
   String name;
   String birth;
   String place;
   String teachers;
   String students;
   String services;
   String designation;
   String writings;
   String death;
   String tomb;
   String degree;
 

}