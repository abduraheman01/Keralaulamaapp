import 'package:flutter/material.dart';

import 'package:keralaulama/classes/class.dart';


class Description extends StatelessWidget {
  const Description({
    super.key,
    required this.sample,
  });
  final ItemClass sample;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Center(
                child: SizedBox(
                  width: 150,
                  height: 150,
                  child: CircleAvatar(
                      backgroundImage: AssetImage(sample.imagePath)),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              // Center(
              //   child: FittedBox(
              //       child: Text(
              //     box.title,
              //     style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              //   )),
              // ),
              SizedBox(
                height: 15,
              ),
              Container(
                width: double.infinity,
                child: Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'പൂർണ നാമം ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.name,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'ജനനം ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.birth,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'സ്വദേശം ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.place,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'ഗുരുനാഥർ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.teachers,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'ശിഷ്യർ ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.students,
                        style: TextStyle(
                          color: Colors.grey[700],
                        ),
                        textAlign: TextAlign.left,
                        
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'സേവനങ്ങൾ ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.services,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'പദവികൾ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.designation,
                        style: TextStyle(
                          
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'രചനകൾ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.writings,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'വഫാത്ത് ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.death,
                        style: TextStyle(
                          
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,

                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'മഖ്ബറ  ',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.tomb,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                      SizedBox(
                        height: 10 ,
                      ),
                      Text(
                        'ബിരുദം',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        sample.degree,
                        style: TextStyle(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
