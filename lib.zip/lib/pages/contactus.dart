import 'package:flutter/material.dart';

class ContactUsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Contact Us',
          style: TextStyle(fontFamily: 'Montserrat-SemiBold'),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Contact Us',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Montserrat-SemiBold'),
            ),
            SizedBox(height: 16),
            Text(
              'If you have any questions, suggestions, or feedback, please don\'t hesitate to get in touch with us. We are here to assist you!',
              style: TextStyle(fontSize: 16, fontFamily: 'Montserrat-SemiBold'),
            ),
            SizedBox(height: 24),
            Text(
              'Contact Information',
              style: TextStyle(
                fontFamily: 'Montserrat-SemiBold',
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            ListTile(
              leading: Icon(Icons.email),
              title: Text(
                'Email',
                style: TextStyle(fontFamily: 'Montserrat-SemiBold'),
              ),
              subtitle: Text(
                'keralaulamadirectoryapp@gmail.com',
                style: TextStyle(fontFamily: 'Montserrat-SemiBold'),
              ),
              onTap: () {
                // Implement email functionality
              },
            ),

            ListTile(
              leading: Icon(Icons.phone),
              title: Text(
                'Phone',
                style: TextStyle(fontFamily: 'Montserrat-SemiBold'),
              ),
              subtitle: Text(
                '9497268306',
                style: TextStyle(fontFamily: 'Montserrat-SemiBold'),
              ),
              onTap: () {
                // Implement phone functionality
              },
            ),
            ListTile(
              leading: Icon(Icons.send),
              title: Text(
                'Whatsapp',
                style: TextStyle(fontFamily: 'Montserrat-SemiBold'),
              ),
              subtitle: Text(
                '''
8281910734
9497268306
''',
                style: TextStyle(fontFamily: 'Montserrat-SemiBold'),
              ),
              onTap: () {
                // Implement phone functionality
              },
            ),
            // Add more contact information as needed
          ],
        ),
      ),
    );
  }
}
